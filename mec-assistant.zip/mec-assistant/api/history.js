// api/history.js
// Admin-only. Lists chat history, optionally filtered by a search term
// matched against the student's name or the question text.

const { getSupabaseAdmin } = require('../lib/supabaseAdmin');
const { requireAdmin } = require('../lib/auth');

module.exports = async function handler(req, res) {
  if (req.method !== 'GET') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const admin = await requireAdmin(req, res);
  if (!admin) return;

  try {
    const search = (req.query.search || '').trim();
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);

    const supabase = getSupabaseAdmin();
    let query = supabase
      .from('chat_history')
      .select('id, student_name, session_id, question, answer, created_at')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (search) {
      // Match against student name OR the question text
      query = query.or(
        `student_name.ilike.%${search}%,question.ilike.%${search}%`
      );
    }

    const { data, error } = await query;
    if (error) throw error;

    res.status(200).json({ history: data });
  } catch (err) {
    console.error('history.js error:', err);
    res.status(500).json({ error: 'Could not load history.' });
  }
};
