// api/config.js
// Returns the PUBLIC Supabase URL + anon key so the frontend can initialise
// supabase-js for admin login. The anon key is safe to expose by design —
// real data access is protected by RLS + the service role key on the server.

module.exports = async function handler(req, res) {
  res.status(200).json({
    supabaseUrl: process.env.SUPABASE_URL || '',
    supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '',
  });
};
